#include <stdio.h>

void id();
void sum100();

void main() {
	printf("OSNW2023\n");
	id();
	sum100();
}

