#include <stdio.h>

void id(){
	printf("32193625 LeeCheolMin\n");
}

